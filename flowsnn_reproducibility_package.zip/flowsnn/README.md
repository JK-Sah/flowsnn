# FlowSNN — Bio-Inspired Lateral-Line Flow Classification with Spiking Neural Networks

Code for the paper:

> J. K. Sah, "Energy-Efficient Hydrodynamic Flow Sensing for Autonomous Underwater Vehicles: A Spiking Neural Network Decoder for a Bio-Inspired Artificial Lateral Line with FSI Simulation and Lattice-Boltzmann CFD Validation", *Ocean Engineering*, 2026.

## Contents

| File | Description |
|---|---|
| `flowsnn_run_experiments.py` | Main PyTorch training script (3-seed, GPU/MPS/CPU) |
| `flowsnn_experiments.py` | NumPy prototype for rapid experimentation |

## Requirements

```
torch >= 2.0
numpy
```

## Usage

```bash
python flowsnn_run_experiments.py          # full 3-seed run
python flowsnn_run_experiments.py --resume # resume from checkpoint
```

Results are written to `flowsnn_results.json`.

## Citation

```bibtex
@article{sah2026flowsnn,
  author  = {Sah, J. K.},
  title   = {Energy-Efficient Hydrodynamic Flow Sensing for Autonomous Underwater Vehicles},
  journal = {Ocean Engineering},
  year    = {2026},
  doi     = {TBD}
}
```

## License

MIT
